import { Link, useParams, Navigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { posts, getPost } from '../data/blogData';

function Block({ block }) {
  if (block.type === 'h2')
    return (
      <h2 className="mt-4 font-display text-2xl font-extrabold leading-tight tracking-[-0.02em] text-ink sm:text-3xl">
        {block.text}
      </h2>
    );
  if (block.type === 'quote')
    return (
      <blockquote className="text-pretty rounded-r-xl border-l-[3px] border-bronze bg-white py-5 pl-6 pr-7 font-display text-[19px] font-bold leading-snug tracking-[-0.01em] text-ink sm:text-[22px]">
        {block.text}
      </blockquote>
    );
  if (block.type === 'list')
    return (
      <ul className="flex list-disc flex-col gap-2.5 pl-6">
        {block.items.map((it) => (
          <li key={it} className="text-pretty text-[17.5px] leading-relaxed text-stone-700">
            {it}
          </li>
        ))}
      </ul>
    );
  return <p className="text-pretty text-[17.5px] leading-[1.75] text-stone-700">{block.text}</p>;
}

export default function Article() {
  const { slug } = useParams();
  const post = getPost(slug);
  if (!post) return <Navigate to="/blog" replace />;

  const related = posts.filter((p) => p.slug !== post.slug).slice(0, 3);

  return (
    <>
      <article className="mx-auto max-w-[760px] px-5 pt-10 sm:px-10 sm:pt-16">
        <Link to="/blog" className="flex items-center gap-1.5 text-[14.5px] font-semibold text-bronze">
          <ArrowLeft className="h-4 w-4" /> Volver al blog
        </Link>

        <div className="mt-6 flex items-center gap-2.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-stone-400">
          <span className="font-semibold text-bronze">{post.category}</span>
          <span>·</span>
          <span>{post.date}</span>
          <span>·</span>
          <span>{post.readingTime}</span>
        </div>

        <h1 className="mt-3.5 text-balance font-display text-[32px] font-extrabold leading-[1.08] tracking-[-0.03em] text-ink sm:text-5xl">
          {post.title}
        </h1>
        <p className="mt-4 text-pretty text-[17px] leading-relaxed text-stone-500 sm:text-[19.5px]">
          {post.excerpt}
        </p>

        <div className="mt-7 flex items-center gap-3 border-b border-stone-200 pb-7">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-stone-200 font-display text-sm font-extrabold text-stone-600">
            {post.authorInitials}
          </span>
          <span className="flex flex-col leading-snug">
            <span className="text-[14.5px] font-semibold text-ink">{post.author}</span>
            <span className="text-[13.5px] text-stone-400">{post.authorRole}</span>
          </span>
        </div>

        <div className="mt-8 aspect-video overflow-hidden rounded-xl bg-stone-200">
          <img src={post.img} alt={post.title} className="h-full w-full object-cover" />
        </div>

        <div className="mt-10 flex flex-col gap-6">
          {post.body.map((b, i) => (
            <Block key={i} block={b} />
          ))}
        </div>
      </article>

      {/* CTA final */}
      <section className="mx-auto mt-12 max-w-[760px] px-5 sm:mt-16 sm:px-10">
        <div className="flex flex-col items-start gap-4 rounded-2xl bg-ink p-7 sm:p-11">
          <span className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.18em] text-bronze-light">
            Asesoramiento
          </span>
          <h2 className="text-balance font-display text-2xl font-extrabold leading-tight tracking-[-0.02em] text-white sm:text-[32px]">
            ¿Querés analizar tu caso con un asesor?
          </h2>
          <p className="max-w-md text-pretty text-[16.5px] leading-relaxed text-stone-400">
            Revisamos tu presupuesto, plazos y objetivos de renta, y te mostramos qué unidades de
            nuestros desarrollos encajan.
          </p>
          <Link
            to="/#contacto"
            className="mt-1.5 rounded-lg bg-bronze px-6 py-3.5 text-[15px] font-semibold text-white transition-colors hover:bg-bronze-light hover:text-white"
          >
            Contactar a un asesor
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-shell px-5 py-14 sm:px-10 sm:py-24">
        <h2 className="mb-6 font-display text-[22px] font-extrabold tracking-[-0.02em] text-ink sm:text-[28px]">
          Seguí leyendo
        </h2>
        <div className="grid gap-6 sm:grid-cols-3">
          {related.map((p) => (
            <Link
              key={p.slug}
              to={`/blog/${p.slug}`}
              className="flex flex-col gap-2.5 rounded-xl border border-stone-200 bg-white p-5 transition-all duration-200 hover:-translate-y-1 hover:shadow-lg"
            >
              <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.12em] text-bronze">
                {p.category}
              </span>
              <h3 className="text-pretty font-display text-[18.5px] font-extrabold leading-snug text-ink">
                {p.title}
              </h3>
              <span className="text-[13.5px] text-stone-400">{p.readingTime}</span>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
