import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { posts, categories } from '../data/blogData';

export default function Blog() {
  const [category, setCategory] = useState('Todos');
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return posts.filter(
      (p) =>
        (category === 'Todos' || p.category === category) &&
        (!q || `${p.title} ${p.excerpt} ${p.category}`.toLowerCase().includes(q))
    );
  }, [category, query]);

  return (
    <>
      <section className="mx-auto max-w-shell px-5 pb-8 pt-12 sm:px-10 sm:pt-20">
        <div className="flex max-w-2xl flex-col gap-4">
          <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-bronze">
            Blog
          </span>
          <h1 className="text-balance font-display text-[34px] font-extrabold leading-[1.05] tracking-[-0.03em] text-ink sm:text-[54px]">
            Novedades, mercado e inversión inmobiliaria
          </h1>
          <p className="max-w-xl text-pretty text-base leading-relaxed text-stone-500 sm:text-lg">
            Análisis del mercado, avances de obra y guías prácticas para invertir en desarrollos desde
            el pozo.
          </p>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 sm:mt-10">
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => {
              const on = c === category;
              return (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`rounded-full border px-5 py-2.5 text-sm font-semibold transition-colors ${
                    on
                      ? 'border-ink bg-ink text-white'
                      : 'border-stone-200 bg-white text-stone-600 hover:border-bronze hover:text-bronze'
                  }`}
                >
                  {c}
                </button>
              );
            })}
          </div>
          <div className="relative w-full sm:w-[260px]">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar artículos"
              className="w-full rounded-full border border-stone-200 bg-white py-3 pl-11 pr-4 text-[14.5px] text-ink outline-none placeholder:text-stone-400 focus:border-bronze"
            />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-shell px-5 pb-14 sm:px-10 sm:pb-24">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((p) => (
            <Link
              key={p.slug}
              to={`/blog/${p.slug}`}
              className="flex flex-col overflow-hidden rounded-xl border border-stone-200 bg-white shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="aspect-[16/10] overflow-hidden bg-stone-200">
                <img src={p.img} alt={p.title} loading="lazy" className="h-full w-full object-cover" />
              </div>
              <div className="flex flex-1 flex-col gap-3 p-5">
                <div className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.12em] text-stone-400">
                  <span className="font-semibold text-bronze">{p.category}</span>
                  <span>·</span>
                  <span>{p.date}</span>
                  <span>·</span>
                  <span>{p.readingTime}</span>
                </div>
                <h2 className="text-pretty font-display text-[21px] font-extrabold leading-tight tracking-[-0.02em] text-ink">
                  {p.title}
                </h2>
                <p className="text-pretty text-[14.5px] leading-relaxed text-stone-500">{p.excerpt}</p>
                <span className="mt-auto pt-1.5 text-[14.5px] font-semibold text-bronze">
                  Leer artículo
                </span>
              </div>
            </Link>
          ))}
        </div>
        {visible.length === 0 && (
          <p className="text-[15.5px] text-stone-500">No encontramos artículos para esa búsqueda.</p>
        )}
      </section>
    </>
  );
}
