export const categories = ['Todos', 'Inversiones', 'Arquitectura', 'Mercado'];

export const posts = [
  {
    slug: 'guia-invertir-en-pozo',
    category: 'Inversiones',
    date: '12 jul 2026',
    readingTime: '7 min de lectura',
    title: 'Guía para invertir en pozo: qué mirar antes de firmar',
    excerpt:
      'Cómo evaluar fideicomiso, plan de pagos y avance de obra para entrar en un desarrollo con el mejor precio por metro cuadrado.',
    img: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1200&q=80&auto=format&fit=crop',
    author: 'Martina Alsina',
    authorRole: 'Directora comercial',
    authorInitials: 'MA',
    body: [
      {
        type: 'p',
        text: 'Comprar en pozo sigue siendo la vía más accesible para entrar a un desarrollo residencial: el precio por metro cuadrado al inicio de obra suele ubicarse entre un 20% y un 30% por debajo del valor de la unidad terminada. Esa diferencia es la compensación por el plazo y por el riesgo de obra, y ahí está el trabajo del inversor: entender qué parte de ese riesgo puede controlar.',
      },
      { type: 'h2', text: '1. La estructura legal antes que el plano' },
      {
        type: 'p',
        text: 'Antes de mirar amenities o terminaciones, revisá el instrumento jurídico. En Argentina la figura más habitual es el fideicomiso al costo o a precio fijo, y cada uno reparte el riesgo de manera distinta: al costo, las variaciones de materiales las absorbe el inversor; a precio fijo, la desarrolladora. Pedí el contrato completo, el reglamento y la nómina de profesionales intervinientes.',
      },
      { type: 'h2', text: '2. Trayectoria verificable de la desarrolladora' },
      {
        type: 'p',
        text: 'Un historial de obras entregadas dice más que cualquier render. Pedí direcciones de proyectos anteriores, hablá con propietarios de esos edificios y compará las fechas de entrega prometidas con las reales.',
      },
      {
        type: 'quote',
        text: 'El mejor indicador de cuándo va a entregar una desarrolladora es cuándo entregó la última vez.',
      },
      { type: 'h2', text: '3. El plan de pagos, medido en tu flujo de caja' },
      {
        type: 'p',
        text: 'El anticipo típico ronda el 30%, con el resto en cuotas ajustables por índice de la construcción durante la obra. Simulá el escenario con el índice corriendo por encima de tus ingresos: si en ese escenario las cuotas siguen siendo pagables, el proyecto es viable para vos.',
      },
      {
        type: 'list',
        items: [
          'Anticipo y refuerzos: cuántos y en qué meses caen.',
          'Índice de ajuste y tope, si existe.',
          'Penalidades por atraso y condiciones de cesión de la unidad.',
          'Gastos de escrituración e impuestos no incluidos en el precio.',
        ],
      },
      { type: 'h2', text: '4. Qué esperar en cada etapa' },
      {
        type: 'p',
        text: 'En excavación y estructura la revalorización es la más alta y el plazo el más largo. Sobre el final de obra el precio ya casi alcanzó el valor de mercado y la ventaja pasa a ser la certeza. No hay una etapa correcta: hay una etapa correcta para tu horizonte de inversión.',
      },
    ],
  },
  {
    slug: 'zonas-en-desarrollo',
    category: 'Mercado',
    date: '28 jun 2026',
    readingTime: '6 min de lectura',
    title: '¿Por qué invertir en zonas en desarrollo?',
    excerpt:
      'Infraestructura, transporte y rezonificación: las tres señales que anticipan la revalorización de un barrio antes que el mercado.',
    img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&q=80&auto=format&fit=crop',
    author: 'Ignacio Ferrer',
    authorRole: 'Análisis de mercado',
    authorInitials: 'IF',
    body: [
      {
        type: 'p',
        text: 'Las zonas consolidadas ofrecen previsibilidad y poco margen. Los barrios en transformación ofrecen lo contrario, y el trabajo consiste en distinguir la transformación real de la promesa de folleto.',
      },
      { type: 'h2', text: 'Obra pública que ya está licitada' },
      {
        type: 'p',
        text: 'Una estación de tren, un puente o una red cloacal cambian el valor del suelo de una zona entera. La diferencia entre una expectativa y un dato es el expediente: si la obra está licitada y adjudicada, tiene fecha; si está anunciada, no.',
      },
      {
        type: 'quote',
        text: 'El suelo no se revaloriza por el edificio que se construye encima, sino por lo que pasa alrededor.',
      },
      { type: 'h2', text: 'Rezonificación y altura permitida' },
      {
        type: 'p',
        text: 'Un cambio de código urbanístico que habilita más altura multiplica la capacidad constructiva de cada lote. Cuando eso ocurre, los desarrolladores entran primero y el precio del metro cuadrado se ajusta después.',
      },
      { type: 'h2', text: 'Comercio y densidad como confirmación' },
      {
        type: 'p',
        text: 'La aparición de gastronomía, coworkings y locales de cadenas es una señal tardía pero confiable: significa que la demanda ya está instalada. Comprar en ese momento implica menos riesgo y menos upside.',
      },
      {
        type: 'list',
        items: [
          'Precio del metro cuadrado versus barrios linderos consolidados.',
          'Permisos de obra nueva otorgados en los últimos 24 meses.',
          'Cobertura de transporte a menos de 800 metros.',
        ],
      },
      {
        type: 'p',
        text: 'Ninguna de estas señales alcanza por separado. Cuando dos o tres coinciden en el mismo radio, la zona ya cambió y el precio todavía no lo refleja.',
      },
    ],
  },
  {
    slug: 'materiales-y-eficiencia',
    category: 'Arquitectura',
    date: '9 jun 2026',
    readingTime: '5 min de lectura',
    title: 'Eficiencia energética: decisiones de proyecto que bajan expensas',
    excerpt:
      'Orientación, envolvente y ventilación cruzada definen el costo de vivir en el edificio durante los próximos treinta años.',
    img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80&auto=format&fit=crop',
    author: 'Lucía Prieto',
    authorRole: 'Dirección de obra',
    authorInitials: 'LP',
    body: [
      {
        type: 'p',
        text: 'El precio de una unidad se negocia una vez; las expensas se pagan todos los meses. Buena parte de ese gasto se define en la etapa de proyecto, mucho antes de que se elija un revestimiento.',
      },
      { type: 'h2', text: 'Orientación y asoleamiento' },
      {
        type: 'p',
        text: 'En el hemisferio sur, los ambientes principales al norte reciben sol durante todo el invierno y admiten protección simple en verano. Es la decisión de menor costo y mayor impacto en confort térmico.',
      },
      { type: 'h2', text: 'La envolvente hace el trabajo silencioso' },
      {
        type: 'p',
        text: 'Aislación en muros y cubierta, doble vidriado hermético y ruptura de puentes térmicos reducen la demanda de climatización sin depender del comportamiento de cada propietario.',
      },
      {
        type: 'quote',
        text: 'Un edificio bien orientado y bien aislado gasta menos incluso cuando nadie está prestando atención.',
      },
      { type: 'h2', text: 'Instalaciones medibles' },
      {
        type: 'p',
        text: 'Medición individual de agua caliente y calefacción, iluminación LED en espacios comunes y bombas de velocidad variable trasladan el gasto a quien lo genera y suelen amortizarse en pocos años.',
      },
      {
        type: 'p',
        text: 'En nuestros desarrollos estas definiciones se toman en la etapa de anteproyecto, cuando todavía son gratuitas. Corregirlas después de la estructura cuesta diez veces más.',
      },
    ],
  },
  {
    slug: 'renta-vs-reventa',
    category: 'Inversiones',
    date: '21 may 2026',
    readingTime: '6 min de lectura',
    title: 'Renta o reventa: cómo elegir la estrategia de salida',
    excerpt:
      'Dos caminos distintos para la misma unidad. La decisión se toma al comprar, no al terminar la obra.',
    img: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200&q=80&auto=format&fit=crop',
    author: 'Martina Alsina',
    authorRole: 'Directora comercial',
    authorInitials: 'MA',
    body: [
      {
        type: 'p',
        text: 'Toda inversión en pozo termina de una de dos maneras: la unidad se vende al terminar la obra o se conserva para alquilar. Las dos son razonables, pero exigen unidades distintas.',
      },
      { type: 'h2', text: 'Reventa: liquidez sobre plazo' },
      {
        type: 'p',
        text: 'La reventa busca capturar la diferencia entre el precio de pozo y el de unidad terminada en el menor tiempo posible. Favorece tipologías de alta demanda —monoambientes y dos ambientes— y proyectos con fecha de entrega creíble.',
      },
      { type: 'h2', text: 'Renta: flujo sobre revalorización' },
      {
        type: 'p',
        text: 'La renta prioriza ubicación, cercanía a transporte y costo de expensas, porque son los factores que sostienen la ocupación. Los rendimientos brutos en el mercado local se ubican habitualmente entre el 4% y el 6% anual en dólares.',
      },
      { type: 'quote', text: 'La estrategia de salida define qué unidad comprás, no al revés.' },
      {
        type: 'list',
        items: [
          'Horizonte de inversión y necesidad de liquidez.',
          'Tipología y superficie según el inquilino objetivo.',
          'Costo de expensas proyectado sobre el valor del alquiler.',
          'Carga impositiva de cada camino.',
        ],
      },
      {
        type: 'p',
        text: 'Antes de reservar conviene escribir la estrategia en una línea. Si no puede escribirse, todavía falta información.',
      },
    ],
  },
];

export const getPost = (slug) => posts.find((p) => p.slug === slug);
