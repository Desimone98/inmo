# Aurea Desarrollos — landing

React + Vite + Tailwind CSS.

## Local
\`\`\`bash
npm install
npm run dev
\`\`\`

## Deploy en Vercel
1. Subí esta carpeta a un repositorio de GitHub.
2. En Vercel: **Add New → Project → Import** el repo.
3. Framework Preset: **Vite** (se detecta solo).
   - Build Command: \`npm run build\`
   - Output Directory: \`dist\`
4. Deploy. No hace falta ninguna variable de entorno.

## Estructura
\`\`\`
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── index.css
    └── data/projects.js
\`\`\`
