import { useEffect } from 'react';
import { Routes, Route, Link, NavLink, useLocation } from 'react-router-dom';
import { Instagram, Linkedin, Facebook } from 'lucide-react';
import Home from './pages/Home';
import Blog from './pages/Blog';
import Article from './pages/Article';

const NAV = [
  { label: 'Inicio', to: '/' },
  { label: 'Proyectos', to: '/#proyectos' },
  { label: 'Nosotros', to: '/#nosotros' },
  { label: 'Blog', to: '/blog' },
];

/** Sube al tope al cambiar de ruta y respeta los anchors /#seccion. */
function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.slice(1));
      if (el) {
        window.scrollTo({ top: el.offsetTop - 90, behavior: 'smooth' });
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-stone-200 bg-stone-50/85 backdrop-blur">
      <div className="mx-auto flex h-[76px] max-w-shell items-center justify-between gap-6 px-5 sm:px-10">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid h-[34px] w-[34px] place-items-center rounded bg-ink font-display text-xs font-black tracking-[0.02em] text-bronze-light">
            NMI
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-display text-[19px] font-extrabold uppercase tracking-[0.04em] text-ink">
              NMI
            </span>
            <span className="mt-[3px] font-mono text-[9.5px] uppercase tracking-[0.22em] text-bronze">
              Desarrollos
            </span>
          </span>
        </Link>

        <nav className="flex items-center gap-5 sm:gap-7">
          {NAV.map((n) =>
            n.to.includes('#') ? (
              <Link
                key={n.label}
                to={n.to}
                className="hidden text-[15px] font-medium text-stone-500 hover:text-bronze sm:block"
              >
                {n.label}
              </Link>
            ) : (
              <NavLink
                key={n.label}
                to={n.to}
                end
                className={({ isActive }) =>
                  `hidden text-[15px] font-medium hover:text-bronze sm:block ${
                    isActive ? 'text-bronze' : 'text-stone-500'
                  }`
                }
              >
                {n.label}
              </NavLink>
            )
          )}
          <Link
            to="/#contacto"
            className="rounded-md bg-ink px-6 py-2.5 text-[15px] font-semibold text-white transition-colors hover:bg-bronze hover:text-white"
          >
            Contactar
          </Link>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-stone-200 bg-white">
      <div className="mx-auto grid max-w-shell gap-10 px-5 py-12 sm:grid-cols-3 sm:px-10 sm:py-14">
        <div className="flex flex-col gap-3">
          <span className="font-display text-[18px] font-extrabold uppercase tracking-[0.04em] text-ink">
            NMI <span className="text-bronze">Desarrollos</span>
          </span>
          <p className="max-w-xs text-[14.5px] leading-relaxed text-stone-500">
            Desarrollo, construcción y comercialización de proyectos residenciales en Argentina.
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <span className="text-[13px] font-bold text-ink">Enlaces rápidos</span>
          {[...NAV, { label: 'Contactar', to: '/#contacto' }].map((n) => (
            <Link key={n.label} to={n.to} className="text-[14.5px] text-stone-500">
              {n.label}
            </Link>
          ))}
        </div>
        <div className="flex flex-col gap-3">
          <span className="text-[13px] font-bold text-ink">Redes</span>
          {[
            { label: 'Instagram', Icon: Instagram },
            { label: 'LinkedIn', Icon: Linkedin },
            { label: 'Facebook', Icon: Facebook },
          ].map(({ label, Icon }) => (
            <a
              key={label}
              href="https://www.google.com"
              className="flex items-center gap-2 text-[14.5px] text-stone-500"
            >
              <Icon className="h-4 w-4" strokeWidth={2} /> {label}
            </a>
          ))}
        </div>
      </div>
      <div className="border-t border-stone-100">
        <div className="mx-auto max-w-shell px-5 py-5 text-[13.5px] text-stone-400 sm:px-10">
          © 2026 NMI Desarrollos. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-stone-50">
      <ScrollManager />
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:slug" element={<Article />} />
        <Route path="*" element={<Home />} />
      </Routes>
      <Footer />
    </div>
  );
}
