// Número de WhatsApp a definir por el cliente (formato internacional, sin + ni espacios)
export const WHATSAPP_NUMBER = '5491140001234';

export const whatsappLink = (project) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    `Hola, quiero hablar con un asesor sobre ${project}.`
  )}`;

export const stats = [
  { value: '+150.000 m²', label: 'Construidos' },
  { value: '15 años', label: 'De trayectoria' },
  { value: '12', label: 'Proyectos terminados' },
  { value: '4', label: 'Obras en curso' },
];

export const projects = [
  {
    id: 'torre-norte',
    img: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=900&q=80&auto=format&fit=crop',
    badge: 'En pozo',
    badgeClass: 'bg-bronze text-white',
    name: 'Torre Norte',
    address: 'Av. Libertador 3400, Núñez',
    delivery: 'Marzo 2028',
    units: '84 unidades',
  },
  {
    id: 'los-olivos',
    img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=80&auto=format&fit=crop',
    badge: 'Pre-venta',
    badgeClass: 'bg-ink text-white',
    name: 'Complejo Los Olivos',
    address: 'Ruta 27 km 4, Nordelta',
    delivery: 'Diciembre 2027',
    units: '36 viviendas',
  },
  {
    id: 'juramento',
    img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&q=80&auto=format&fit=crop',
    badge: 'Terminado',
    badgeClass: 'bg-stone-100 text-stone-600',
    name: 'Residencias Juramento',
    address: 'Juramento 2150, Belgrano',
    delivery: 'Entregado 2024',
    units: '52 unidades',
  },
];

export const filters = {
  estado: ['En pozo', 'En construcción', 'Entregados'],
  ubicacion: ['Palermo', 'Belgrano', 'Nordelta', 'Rosario Centro'],
  tipo: ['Torre residencial', 'Complejo de viviendas', 'Uso mixto', 'Loteo'],
};
