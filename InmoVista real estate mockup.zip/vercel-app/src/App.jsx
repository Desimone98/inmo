import { useState } from 'react';
import {
  Building2,
  CalendarDays,
  Layers,
  Instagram,
  Linkedin,
  Facebook,
  ArrowRight,
  Search,
} from 'lucide-react';
import { stats, projects, filters } from './data/projects';

const NAV = [
  { label: 'Inicio', href: '#inicio' },
  { label: 'Proyectos', href: '#proyectos' },
  { label: 'Nosotros', href: '#nosotros' },
];

function Select({ label, options }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="pl-0.5 text-xs font-semibold text-stone-500">{label}</span>
      <select className="w-full cursor-pointer appearance-none rounded-lg border border-stone-200 bg-stone-50 px-4 py-3 text-[15px] text-ink outline-none focus:border-bronze">
        {options.map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    </label>
  );
}

function Logo({ className = '' }) {
  return (
    <a href="#inicio" className={`flex items-center gap-3 ${className}`}>
      <span className="grid h-8 w-8 place-items-center rounded bg-ink">
        <Building2 className="h-4 w-4 text-bronze-light" strokeWidth={2} />
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-[19px] font-extrabold uppercase tracking-[0.04em] text-ink">
          Aurea
        </span>
        <span className="mt-[3px] font-mono text-[9.5px] uppercase tracking-[0.22em] text-bronze">
          Desarrollos
        </span>
      </span>
    </a>
  );
}

export default function App() {
  const [sent, setSent] = useState(false);

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Navbar */}
      <header className="sticky top-0 z-50 border-b border-stone-200 bg-stone-50/85 backdrop-blur">
        <div className="mx-auto flex h-[76px] max-w-shell items-center justify-between gap-6 px-5 sm:px-10">
          <Logo />
          <nav className="flex items-center gap-6 sm:gap-8">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="hidden text-[15px] font-medium text-stone-500 hover:text-bronze sm:block"
              >
                {n.label}
              </a>
            ))}
            <a
              href="#contacto"
              className="rounded-md bg-ink px-6 py-2.5 text-[15px] font-semibold text-white transition-colors hover:bg-bronze hover:text-white"
            >
              Contactar
            </a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section id="inicio" className="mx-auto max-w-shell px-5 pb-10 pt-14 sm:px-10 sm:pt-24">
        <div className="flex max-w-3xl flex-col gap-5">
          <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-bronze">
            Desarrolladora inmobiliaria
          </span>
          <h1 className="text-balance font-display text-4xl font-extrabold leading-[1.04] tracking-[-0.03em] text-ink sm:text-6xl">
            Diseñamos y construimos el futuro urbano
          </h1>
          <p className="max-w-xl text-pretty text-base leading-relaxed text-stone-500 sm:text-[19px]">
            Desarrollos residenciales propios, desde el pozo hasta la entrega de llaves. Invertí en
            obra con respaldo y trayectoria.
          </p>
        </div>

        {/* Buscador */}
        <div className="mt-10 grid items-end gap-3 rounded-xl border border-stone-200 bg-white p-3.5 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
          <Select label="Estado de obra" options={filters.estado} />
          <Select label="Ubicación" options={filters.ubicacion} />
          <Select label="Tipo de desarrollo" options={filters.tipo} />
          <button className="flex items-center justify-center gap-2 rounded-lg bg-ink px-6 py-3.5 text-[15px] font-semibold text-white transition-colors hover:bg-bronze active:scale-[0.98]">
            <Search className="h-4 w-4" strokeWidth={2} />
            Buscar
          </button>
        </div>
      </section>

      {/* Trayectoria */}
      <section className="mx-auto max-w-shell px-5 pb-14 sm:px-10 sm:pb-20">
        <div className="grid gap-8 border-y border-stone-200 py-8 sm:grid-cols-2 lg:grid-cols-4 sm:py-10">
          {stats.map((s) => (
            <div key={s.label} className="flex flex-col gap-1.5">
              <span className="font-display text-3xl font-extrabold leading-none tracking-[-0.03em] text-bronze sm:text-[40px]">
                {s.value}
              </span>
              <span className="text-[14.5px] text-stone-500">{s.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Proyectos */}
      <section id="proyectos" className="mx-auto max-w-shell px-5 pb-14 sm:px-10 sm:pb-20">
        <div className="mb-8 flex flex-wrap items-baseline justify-between gap-5">
          <h2 className="font-display text-[26px] font-extrabold tracking-[-0.02em] text-ink sm:text-[38px]">
            Nuestros desarrollos
          </h2>
          <a href="#proyectos" className="text-[15px] font-semibold text-bronze">
            Ver todos los proyectos
          </a>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <article
              key={p.id}
              className="flex flex-col overflow-hidden rounded-xl border border-stone-200 bg-white shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-stone-200">
                <img src={p.img} alt={p.name} className="h-full w-full object-cover" loading="lazy" />
                <span
                  className={`absolute left-3.5 top-3.5 rounded px-3 py-1.5 font-mono text-[10.5px] font-semibold uppercase tracking-[0.1em] ${p.badgeClass}`}
                >
                  {p.badge}
                </span>
              </div>
              <div className="flex flex-1 flex-col gap-4 p-5">
                <div className="flex flex-col gap-1">
                  <h3 className="font-display text-[23px] font-extrabold tracking-[-0.02em] text-ink">
                    {p.name}
                  </h3>
                  <p className="text-[14.5px] text-stone-500">{p.address}</p>
                </div>
                <div className="grid grid-cols-2 gap-3.5 border-y border-stone-100 py-3.5">
                  <div className="flex flex-col gap-0.5">
                    <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-stone-400">
                      <CalendarDays className="h-3 w-3" strokeWidth={2} /> Entrega
                    </span>
                    <span className="text-[14.5px] font-semibold text-ink">{p.delivery}</span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-stone-400">
                      <Layers className="h-3 w-3" strokeWidth={2} /> Unidades
                    </span>
                    <span className="text-[14.5px] font-semibold text-ink">{p.units}</span>
                  </div>
                </div>
                <button className="mt-auto w-full rounded-lg border border-stone-200 bg-stone-50 py-3 text-[14.5px] font-semibold text-ink transition-colors hover:border-ink hover:bg-ink hover:text-white">
                  Ver proyecto
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Banner catálogo */}
      <section className="mx-auto max-w-shell px-5 pb-14 sm:px-10 sm:pb-20">
        <div className="flex flex-wrap items-center justify-between gap-6 rounded-xl border border-l-[3px] border-stone-200 border-l-bronze bg-white px-6 py-6 sm:px-9 sm:py-7">
          <p className="max-w-2xl text-pretty text-base leading-snug text-stone-700 sm:text-[17.5px]">
            También contamos con un catálogo de propiedades terminadas para alquiler y venta.
          </p>
          <a
            href="#contacto"
            className="flex items-center gap-1.5 whitespace-nowrap text-[15px] font-semibold text-bronze"
          >
            Ver catálogo <ArrowRight className="h-4 w-4" strokeWidth={2} />
          </a>
        </div>
      </section>

      {/* Contacto */}
      <section id="contacto" className="mx-auto mb-14 max-w-shell px-5 sm:mb-24 sm:px-10">
        <div className="grid items-start gap-8 rounded-2xl bg-ink p-8 sm:gap-16 sm:p-16 lg:grid-cols-2">
          <div id="nosotros" className="flex flex-col gap-4">
            <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-bronze-light">
              Contacto
            </span>
            <h2 className="font-display text-[28px] font-extrabold leading-tight tracking-[-0.02em] text-white sm:text-[40px]">
              Conversemos sobre tu próxima inversión
            </h2>
            <p className="max-w-md text-pretty text-[16.5px] leading-relaxed text-stone-400">
              Dejanos tus datos y un asesor te contacta dentro de las 24 horas con la información del
              desarrollo que te interese.
            </p>
            <div className="mt-2 flex flex-col gap-2 text-[15px] text-stone-300">
              <span>inversiones@aureadesarrollos.com</span>
              <span>+54 11 4000 1234</span>
            </div>
          </div>

          <form
            className="flex flex-col gap-3.5"
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
          >
            <input
              type="text"
              placeholder="Nombre"
              required
              className="w-full rounded-lg border border-stone-700 bg-stone-800 px-4 py-3.5 text-[15px] text-white outline-none placeholder:text-stone-500 focus:border-bronze-light"
            />
            <input
              type="email"
              placeholder="Email"
              required
              className="w-full rounded-lg border border-stone-700 bg-stone-800 px-4 py-3.5 text-[15px] text-white outline-none placeholder:text-stone-500 focus:border-bronze-light"
            />
            <textarea
              rows={4}
              placeholder="Mensaje"
              className="w-full resize-y rounded-lg border border-stone-700 bg-stone-800 px-4 py-3.5 text-[15px] text-white outline-none placeholder:text-stone-500 focus:border-bronze-light"
            />
            <button
              type="submit"
              className="rounded-lg bg-bronze py-4 text-[15px] font-semibold text-white transition-colors hover:bg-bronze-light active:scale-[0.98]"
            >
              {sent ? '¡Mensaje enviado!' : 'Enviar mensaje'}
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-white">
        <div className="mx-auto grid max-w-shell gap-10 px-5 py-12 sm:grid-cols-3 sm:px-10 sm:py-14">
          <div className="flex flex-col gap-3">
            <span className="font-display text-[18px] font-extrabold uppercase tracking-[0.04em] text-ink">
              Aurea <span className="text-bronze">Desarrollos</span>
            </span>
            <p className="max-w-xs text-[14.5px] leading-relaxed text-stone-500">
              Desarrollo, construcción y comercialización de proyectos residenciales en Argentina.
            </p>
          </div>
          <div className="flex flex-col gap-3">
            <span className="text-[13px] font-bold text-ink">Enlaces rápidos</span>
            {[...NAV, { label: 'Contactar', href: '#contacto' }].map((n) => (
              <a key={n.label} href={n.href} className="text-[14.5px] text-stone-500">
                {n.label}
              </a>
            ))}
          </div>
          <div className="flex flex-col gap-3">
            <span className="text-[13px] font-bold text-ink">Redes</span>
            {[
              { label: 'Instagram', Icon: Instagram },
              { label: 'LinkedIn', Icon: Linkedin },
              { label: 'Facebook', Icon: Facebook },
            ].map(({ label, Icon }) => (
              <a
                key={label}
                href="#inicio"
                className="flex items-center gap-2 text-[14.5px] text-stone-500"
              >
                <Icon className="h-4 w-4" strokeWidth={2} /> {label}
              </a>
            ))}
          </div>
        </div>
        <div className="border-t border-stone-100">
          <div className="mx-auto max-w-shell px-5 py-5 text-[13.5px] text-stone-400 sm:px-10">
            © 2026 Aurea Desarrollos. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
